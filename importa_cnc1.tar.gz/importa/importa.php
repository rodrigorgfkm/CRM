<?
$bd_host = 'localhost';
$bd_usuario = 'cybernet_cncimporta';
$bd_password = 'UbBv[Txqe0?%';
$bd_base = 'cybernet_cncimporta';

$mysqli = new mysqli($bd_host, $bd_usuario, $bd_password, $bd_base);

/* comprobar la conexión */
if (mysqli_connect_errno()) {
    printf("Falló la conexión: %s\n", mysqli_connect_error());
    exit();
}


/*$con = mysql_connect($bd_host, $bd_usuario, $bd_password) or die('No se puede conectar a la BD');
$bd = mysql_select_db($bd_base, $con);*/

function comilla($txt){
	$txt = str_replace('"', '', $txt);
	$txt = str_replace("'", '', $txt);
	return $txt;
	}
function fecha($fecha){
	$f = explode('/', $fecha);
	return $f[2].'-'.$f[1].'-'.$f[0];
	}

echo '<h1>Importa</h1>';
$n=0;
$fp = fopen ( "cuo_2017_2.txt" , "r" ); 



while(($data = fgetcsv($fp, 10000, "|")) !== FALSE){
	$n++;
	$consulta = 'INSERT INTO cuotas(
	`tabla`, `reg_asoc`, `fecha_cont`, `fecha_pago`, `tipo_cmpte`, 
	`sucu_cmpte`, `nume_cmpte`, `tipo_movim`, `peri_movi`, `gest_movi`, 
	`deta_glosa`, `dola_monto`, `boli_monto`, `tipo_cambi`, `debe_haber`, 
	`obs`, `copi_aliva`, `alta_usuar`, `alta_fecha`, `alta_hora`, 
	`modi_usuar`, `modi_fecha`, `modi_hora`, `baja_usuar`, `baja_fecha`, 
	`baja_hora`
	) VALUES(';
	$consulta.= '"2017", "'.comilla($data[0]).'", "'.comilla($data[1]).'", "'.comilla($data[2]).'", "'.comilla($data[3]).'", ';
	$consulta.= '"'.comilla($data[4]).'", "'.comilla($data[5]).'", "'.comilla($data[6]).'", "'.comilla($data[7]).'", "'.comilla($data[8]).'", ';
	$consulta.= '"'.comilla($data[9]).'", "'.comilla($data[10]).'", "'.comilla($data[11]).'", "'.comilla($data[12]).'", "'.comilla($data[13]).'", ';
	$consulta.= '"'.comilla($data[14]).'", "'.comilla($data[15]).'", "'.comilla($data[16]).'", "'.comilla($data[17]).'", "'.comilla($data[18]).'", ';
	$consulta.= '"'.comilla($data[19]).'", "'.comilla($data[20]).'", "'.comilla($data[21]).'", "'.comilla($data[22]).'", "'.comilla($data[23]).'", ';
	$consulta.= '"'.comilla($data[24]).'"';
	$consulta.= ')';
	echo $consulta.'<br><br>';
	$mysqli->query($consulta);
}



echo '<h3>Terminado '.$n.'</h3>';
fclose ( $fp ); 
?>