<?
$bd_host = 'localhost';
$bd_usuario = 'cybernet_cncsis';
$bd_password = '3X)O[J;MMz@=';
$bd_base = 'cybernet_cncsis';

$mysqli = new mysqli($bd_host, $bd_usuario, $bd_password, $bd_base);

/* comprobar la conexión */
if (mysqli_connect_errno()) {
    printf("Falló la conexión: %s\n", mysqli_connect_error());
    exit();
}


/*$con = mysql_connect($bd_host, $bd_usuario, $bd_password) or die('No se puede conectar a la BD');
$bd = mysql_select_db($bd_base, $con);*/

function comilla($txt){
	$txt = str_replace('"', '', $txt);
	$txt = str_replace("'", '', $txt);
	return $txt;
	}
function fecha($fecha){
	$f = explode('/', $fecha);
	return $f[2].'-'.$f[1].'-'.$f[0];
	}

echo '<h1>Importa</h1>';
$n = 0;
$query = 'SELECT id, bloqueado FROM cgn_erp_clientes WHERE 1 ORDER BY id';
$resultado = $mysqli->query($query);
while ($fila = $resultado->fetch_row()){
	$n++;
	if($fila[1] == 0)
		$estado = 1;
		else
		$estado = 2;
	
	$query = 'INSERT INTO cgn_erp_clientes_rel_estado(`id_cliente`, `id_estado`, `activo`) VALUES(';
	$query.= '"'.$fila[0].'"';
	$query.= ', "'.$estado.'"';
	$query.= ', "1"';
	$query.= ')';
	$mysqli->query($query);
}



echo '<h3>Terminado '.$n.'</h3>';
fclose ( $fp ); 
?>