<html class="no-js" lang="es-UY" data-site="MLU"
      data-country="UY"
      data-device="desktop">
<head>
	<meta charset="utf-8" />
</head>
<body>

<?
$bd_host = 'localhost';
$bd_usuario = 'cybernet_cncimporta';
$bd_password = 'UbBv[Txqe0?%';
$bd_base = 'cybernet_cncimporta';

$mysqli = new mysqli($bd_host, $bd_usuario, $bd_password, $bd_base);

/* comprobar la conexión */
if (mysqli_connect_errno()) {
    printf("Falló la conexión: %s\n", mysqli_connect_error());
    exit();
}


/*$con = mysql_connect($bd_host, $bd_usuario, $bd_password) or die('No se puede conectar a la BD');
$bd = mysql_select_db($bd_base, $con);*/

function comilla($txt){
	$txt = str_replace('"', '', $txt);
	$txt = str_replace("'", '', $txt);
	return $txt;
	}
function fecha($fecha){
	$f = explode('/', $fecha);
	return $f[2].'-'.$f[1].'-'.$f[0];
	}

echo '<h1>Importa</h1>';
$n = 0;
$query = 'SELECT * FROM asociados WHERE id <= 10 ORDER BY id';
$resultado = $mysqli->query($query);
while ($fila = $resultado->fetch_row()){
	echo '<pre>'.$fila[2].' - '.$fila[6].'</pre>';
}



echo '<h3>Terminado '.$n.'</h3>';
fclose ( $fp ); 
?>
</body>
</html>