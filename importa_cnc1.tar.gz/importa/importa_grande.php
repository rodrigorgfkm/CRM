<?
$bd_host = 'localhost';
$bd_usuario = 'cybernet_cncimporta';
$bd_password = 'UbBv[Txqe0?%';
$bd_base = 'cybernet_cncimporta';

$mysqli = new mysqli($bd_host, $bd_usuario, $bd_password, $bd_base);

/* comprobar la conexión */
if (mysqli_connect_errno()) {
    printf("Falló la conexión: %s\n", mysqli_connect_error());
    exit();
}


/*$con = mysql_connect($bd_host, $bd_usuario, $bd_password) or die('No se puede conectar a la BD');
$bd = mysql_select_db($bd_base, $con);*/

function comilla($txt){
	$txt = str_replace('"', '', $txt);
	$txt = str_replace("'", '', $txt);
	return $txt;
	}
function fecha($fecha){
	$f = explode('/', $fecha);
	return $f[2].'-'.$f[1].'-'.$f[0];
	}

echo '<h1>Importa</h1>';
$n=0;
$fp = fopen ( "asociado.txt" , "r" ); 



while(($data = fgetcsv($fp, 10000, "|")) !== FALSE){
		
	$consulta = 'INSERT INTO asociados(
	`reg_asoc`, `raz_soci`, `ruc`, `nit`, `nit_temp`, `contacto`, `tipo_con`, `conemail`, `direccion`, `zona`, 
	`ciudad`, `telefono1`, `telefono2`, `fax_orig`, `fax`, `casilla`, `website`, `email`, `telex`, `mt_recsa`, 
	`fech_inic`, `fecha_insc`, `baja`, `fech_baja`, `ant_ges`, `ant_mes`, `ant_dia`, `otro_info`, `fech_crea`, `nro_empl`, 
	`envio`, `envio_ok`, `envio_re`, `libro`, `tomo`, `partido`, `categoria`, `categoro`, `cuota`, `cuotao`, 
	`cobranza`, `cobraant`, `cobraan2`, `mensajero`, `encuesta`, `insc_por`, `promotor`, `promot_o`, `tipo_soc`, `capital`, 
	`rs_recsa`, `testi_id`, `poder_id`, `obs`, `extravia`, `facturar`, `preiodic`, `periodo`, `sal_cuo1`, `sal_cuot`, 
	`sal_bol1`, `sal_boli`, `sal_dol1`, `sal_dola`, `fac_acum`, `fac_pcob`, `pant_ges`, `pant_mes`, `matr_suc`, `sucu_lpz`, 
	`sucu_cba`, `sucu_scz`, `sucu_oru`, `sucu_chq`, `sucu_ben`, `sucu_pot`, `sucu_tar`, `sucu_pan`, `pers_per`, `pers_eve`, 
	`act_prod`, `act_impo`, `act_expo`, `act_serv`, `act_coma`, `act_come`, `act_desc`, `fech_act`, `alta_usu`, `alta_fech`, 
	`alta_hor`, `modi_usu`, `modi_fech`, `modi_hor`, `baja_usu`, `baja_fech`, `baja_hor`, `temp`, `cuota_dol`, `sal_cuotas`, 
	`sal_mbs`, `sal_mdol`, `sal_utra`, `regasoc`, `fechacum`
	) VALUES(
	"'.comilla($data[0]).'", "'.comilla($data[1]).'", "'.comilla($data[2]).'", "'.comilla($data[3]).'", "'.comilla($data[4]).'", 
	"'.comilla($data[5]).'", "'.comilla($data[6]).'", "'.comilla($data[7]).'", "'.comilla($data[8]).'", "'.comilla($data[9]).'", 
	
	"'.comilla($data[10]).'", "'.comilla($data[11]).'", "'.comilla($data[12]).'", "'.comilla($data[13]).'", "'.comilla($data[14]).'", 
	"'.comilla($data[15]).'", "'.comilla($data[16]).'", "'.comilla($data[17]).'", "'.comilla($data[18]).'", "'.comilla($data[19]).'", 
	
	"'.comilla($data[20]).'", "'.comilla($data[21]).'", "'.comilla($data[22]).'", "'.comilla($data[23]).'", "'.comilla($data[24]).'", 
	"'.comilla($data[25]).'", "'.comilla($data[26]).'", "", "'.comilla($data[27]).'", "'.comilla($data[28]).'",
	 
	"'.comilla($data[29]).'", "'.comilla($data[30]).'", "'.comilla($data[31]).'", "'.comilla($data[32]).'", "'.comilla($data[33]).'", 
	"'.comilla($data[34]).'", "'.comilla($data[35]).'", "'.comilla($data[36]).'", "'.comilla($data[37]).'", "'.comilla($data[38]).'", 
	
	"'.comilla($data[39]).'", "'.comilla($data[40]).'", "'.comilla($data[41]).'", "'.comilla($data[42]).'", "'.comilla($data[43]).'", 
	"'.comilla($data[44]).'", "'.comilla($data[45]).'", "'.comilla($data[46]).'", "'.comilla($data[47]).'", "'.comilla($data[48]).'", 
	
	"'.comilla($data[49]).'", "'.comilla($data[50]).'", "'.comilla($data[51]).'", "'.comilla($data[52]).'", "'.comilla($data[53]).'", 
	"'.comilla($data[54]).'", "'.comilla($data[55]).'", "'.comilla($data[56]).'", "'.comilla($data[57]).'", "'.comilla($data[58]).'", 
	
	"'.comilla($data[59]).'", "'.comilla($data[60]).'", "'.comilla($data[61]).'", "'.comilla($data[62]).'", "'.comilla($data[63]).'", 
	"'.comilla($data[64]).'", "'.comilla($data[65]).'", "'.comilla($data[66]).'", "'.comilla($data[67]).'", "'.comilla($data[68]).'", 
	
	"'.comilla($data[69]).'", "'.comilla($data[70]).'", "'.comilla($data[71]).'", "'.comilla($data[72]).'", "'.comilla($data[73]).'", 
	"'.comilla($data[74]).'", "'.comilla($data[75]).'", "'.comilla($data[76]).'", "'.comilla($data[77]).'", "'.comilla($data[78]).'", 
	
	"'.comilla($data[79]).'", "'.comilla($data[80]).'", "'.comilla($data[81]).'", "'.comilla($data[82]).'", "'.comilla($data[83]).'", 
	"'.comilla($data[84]).'", "'.comilla($data[85]).'", "'.comilla($data[86]).'", "'.comilla($data[87]).'", "'.comilla($data[88]).'", 
	
	"'.comilla($data[89]).'", "'.comilla($data[90]).'", "'.comilla($data[91]).'", "'.comilla($data[92]).'", "'.comilla($data[93]).'", 
	"'.comilla($data[94]).'", "'.comilla($data[95]).'", "'.comilla($data[96]).'", "'.comilla($data[97]).'", "'.comilla($data[98]).'", 
	
	"'.comilla($data[99]).'", "'.comilla($data[100]).'", "'.comilla($data[101]).'", "'.comilla($data[102]).'", "'.comilla($data[103]).'"
	)';
	$mysqli->query($consulta);
	echo $consulta.'<br><br>';
		
	//$sentencia->bind_param("s", '');
	
	/* Ejecutar la sentencia */
	//$sentencia->execute();
	$n++;
	
	//$sentencia->close();
}



echo '<h3>Terminado '.$n.'</h3>';
fclose ( $fp ); 
?>