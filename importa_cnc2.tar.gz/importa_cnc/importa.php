<?
$bd_host = 'localhost';
$bd_usuario = 'cybernet_cncimporta';
$bd_password = 'UbBv[Txqe0?%';
$bd_base = 'cybernet_cncimporta';

$mysqli = new mysqli($bd_host, $bd_usuario, $bd_password, $bd_base);

/* comprobar la conexión */
if (mysqli_connect_errno()) {
    printf("Falló la conexión: %s\n", mysqli_connect_error());
    exit();
}


/*$con = mysql_connect($bd_host, $bd_usuario, $bd_password) or die('No se puede conectar a la BD');
$bd = mysql_select_db($bd_base, $con);*/

function comilla($txt){
	$txt = str_replace('"', '', $txt);
	$txt = str_replace("'", '', $txt);
	return $txt;
	}
function fecha($fecha){
	$f = explode('/', $fecha);
	return $f[2].'-'.$f[1].'-'.$f[0];
	}

echo '<h1>Importa</h1>';
$n=0;
$fp = fopen ( "masiva.txt" , "r" ); 



while(($data = fgetcsv($fp, 10000, "|")) !== FALSE){
		
	$consulta = "INSERT INTO masiva(
	`reg_asoc`, `raz_soci`, `ruc`, `nit`, `cobranza`, 
	`categori`, `sal_bol1`, `sal_boli`, `sal_dol1`, `sal_dola`, 
	`sal_cuo1`, `sal_cuot`, `sucursal`, `nota_alfan`, `nota_numer`, 
	`nota_norde`, `periodo`, `monto_fac`, `proce_fac`, `monto_tc`, 
	`fecha_fact`, `pase_asoc`
	) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	$sentencia = $mysqli->prepare($consulta);
		
	$sentencia->bind_param("ssssssssssssssssssssss", 
	comilla($data[0]), comilla($data[1]), comilla($data[2]), comilla($data[3]), comilla($data[4]), 
	comilla($data[5]), comilla($data[6]), comilla($data[7]), comilla($data[8]), comilla($data[9]), 
	comilla($data[10]), comilla($data[11]), comilla($data[12]), comilla($data[13]), comilla($data[14]), 
	comilla($data[15]), comilla($data[16]), comilla($data[17]), comilla($data[18]), comilla($data[19]), 
	comilla($data[20]), comilla($data[21])
	);
	
	/* Ejecutar la sentencia */
	$sentencia->execute();
	$n++;
	
	$sentencia->close();
}



echo '<h3>Terminado '.$n.'</h3>';
fclose ( $fp ); 
?>