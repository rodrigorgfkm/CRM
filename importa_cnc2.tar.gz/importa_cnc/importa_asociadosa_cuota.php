<?
$bd_host = 'localhost';
$bd_usuario = 'cybernet_cncimporta';
$bd_password = 'UbBv[Txqe0?%';
$bd_base = 'cybernet_cncimporta';

$mysqli = new mysqli($bd_host, $bd_usuario, $bd_password, $bd_base);

/* comprobar la conexión */
if (mysqli_connect_errno()) {
    printf("Falló la conexión: %s\n", mysqli_connect_error());
    exit();
}

$p = $_GET['p'];
if($p == '')
	$p = 0;

/*$con = mysql_connect($bd_host, $bd_usuario, $bd_password) or die('No se puede conectar a la BD');
$bd = mysql_select_db($bd_base, $con);*/

function comilla($txt){
	$txt = str_replace('"', '', $txt);
	$txt = str_replace("'", '', $txt);
	return $txt;
	}
function fecha($fecha){
	$f = explode('/', $fecha);
	return $f[2].'-'.$f[0].'-'.$f[1];
	}

echo '<h1>Importa</h1>';
$n = 0;

$query = 'SELECT * FROM cuotas WHERE id > '.$p.' AND peri_movi != "00-00" ORDER BY id LIMIT 5000';
//$query = 'SELECT * FROM cuotas WHERE 1 ORDER BY id LIMIT 0,30';
$resultado = $mysqli->query($query);

while ($row = $resultado->fetch_row()){
	$n++;
	$reg = (int) $row[2];
	
	$query = 'SELECT id FROM cgn_erp_clientes WHERE registro = "'.$reg.'"';
	$rs = $mysqli->query($query);
	$rw = $rs->fetch_row();
	$id_cliente = $rw[0];
	
	$m = explode('-', $row[9]);
	$cant = ($m[1]+1) - $m[0];
	$monto = $row[13] / $cant;
	
	$query = 'INSERT INTO cgn_erp_aportes_pagos(`id_cliente`, `fecha`, `cant_aportes`, `id_cuota`, `monto`) VALUES(';
	$query.= '"'.$id_cliente.'"';
	$query.= ', "'.fecha($row[4]).'"';
	$query.= ', "'.$cant.'"';
	$query.= ', "'.$row[0].'"';
	$query.= ', "'.$row[13].'"';
	$query.= ')';
	$mysqli->query($query);
	
	$id_pago = $mysqli->insert_id;
	
	for($i=$m[0]; $i<=$m[1]; $i++){
		$query = 'INSERT INTO cgn_erp_aportes_mes(`id_cliente`, `id_pago`, `monto`, `mes`, `anio`) VALUES(';
		$query.= '"'.$id_cliente.'"';
		$query.= ', "'.$id_pago.'"';
		$query.= ', "'.$monto.'"';
		$query.= ', "'.$i.'"';
		$query.= ', "'.$row[10].'"';
		$query.= ')';
		$mysqli->query($query);
		}
		
	$query = 'UPDATE cuotas SET procesado = "1" WHERE id = "'.$row[0].'"';
	$mysqli->query($query);
	
	$id = $row[0];
	}

echo '<h3>Terminado '.$n.'</h3>';

$pag = $_GET['pag'] + 1;
if($p < 577435){
	if($n == 5000)
		echo '<script>location.href = "Imp_asociadosa_cuota.php?p='.$id.'&pag='.$pag.'"</script>';	
	}
?>