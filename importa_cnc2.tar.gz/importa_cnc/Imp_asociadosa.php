<?
$bd_host = 'localhost';
$bd_usuario = 'cybernet_cncimporta';
$bd_password = 'UbBv[Txqe0?%';
$bd_base = 'cybernet_cncimporta';

$mysqli = new mysqli($bd_host, $bd_usuario, $bd_password, $bd_base);

/* comprobar la conexión */
if (mysqli_connect_errno()) {
    printf("Falló la conexión: %s\n", mysqli_connect_error());
    exit();
}


/*$con = mysql_connect($bd_host, $bd_usuario, $bd_password) or die('No se puede conectar a la BD');
$bd = mysql_select_db($bd_base, $con);*/

function comilla($txt){
	$txt = str_replace('"', '', $txt);
	$txt = str_replace("'", '', $txt);
	return $txt;
	}
function fecha($fecha){
	$f = explode('/', $fecha);
	return $f[2].'-'.$f[0].'-'.$f[1];
	}

echo '<h1>Importa</h1>';
$n = 0;

$query = 'SELECT * FROM asociados WHERE 1 ORDER BY id';
$resultado = $mysqli->query($query);

while ($row = $resultado->fetch_row()){
	$n++;
	$reg = (int) $row[1];
	$id_sociedad = (int) $row[49];
	
	$query = 'INSERT INTO cgn_erp_clientes(`id_tiposociedad`, `registro`, `libro`, `tomo`, `part`, `fecha_inscripcion`, `fecha_registro`) VALUES(';
	$query.= '"'.$id_sociedad.'"';
	$query.= ', "'.$reg.'"';
	$query.= ', "'.$row[34].'"';
	$query.= ', "'.$row[35].'"';
	$query.= ', "'.$row[36].'"';
	$query.= ', "'.fecha($row[22]).'"';
	$query.= ', "'.fecha($row[21]).'"';
	$query.= ')';
	$mysqli->query($query);
	
	$id_cliente = $mysqli->insert_id;
	
	$query = 'INSERT INTO cgn_erp_clientes_nit(`id_cliente`, `etiqueta`, `nombre`, `nit`, `principal`) VALUES(';
	$query.= '"'.$id_cliente.'"';
	$query.= ', "'.$row[2].'"';
	$query.= ', "'.$row[2].'"';
	$query.= ', "'.$row[4].'"';
	$query.= ', "1"';
	$query.= ')';
	$mysqli->query($query);
	
	switch($row[23]){
		case 'B':
		$id_estado = 2;
		$fecha = fecha($row[24]);
		break;
		case 'S':
		$id_estado = 3;
		$fecha = fecha($row[24]);
		break;
		default:
		$id_estado = 1;
		$fecha = fecha($row[22]);
		break;
		}
	
	$query = 'INSERT INTO cgn_erp_clientes_rel_estado(`id_cliente`, `id_estado`, `fecha`, `activo`) VALUES(';
	$query.= '"'.$id_cliente.'"';
	$query.= ', "'.$id_estado.'"';
	$query.= ', "'.$fecha.'"';
	$query.= ', "1"';
	$query.= ')';
	$mysqli->query($query);
	
	$id_categoria = (int)$row[37];
	if($row[55] == 'F')
		$extra = 0;
		else
		$extra = 1;
	
	$query = 'INSERT INTO cgn_erp_clientes_info(`id_cliente`, `id_categoria`, `empresa`, `nit`, `nombre`, `direccion`, `zona`, `ciudad`, `activo`, `fecha`, `capital`, `matr_recsa`, `resol_recsa`, `casilla`, `fax`, `extraviado`, `per_permanente`, `per_eventual`, `testimonio`, `poder`) VALUES(';
	$query.= '"'.$id_cliente.'"';
	$query.= ', "'.$id_categoria.'"';
	$query.= ', "'.$row[2].'"';
	$query.= ', "'.$row[4].'"';
	$query.= ', "'.$row[6].'"';
	$query.= ', "'.$row[9].'"';
	$query.= ', "'.$row[10].'"';
	$query.= ', "'.$row[11].'"';
	$query.= ', "1"';
	$query.= ', "'.fecha($row[21]).'"';
	$query.= ', "'.$row[50].'"';
	$query.= ', "'.$row[20].'"';
	$query.= ', "'.$row[51].'"';
	$query.= ', "'.$row[16].'"';
	$query.= ', "'.$row[15].'"';
	$query.= ', "'.$extra.'"';
	$query.= ', "'.$row[79].'"';
	$query.= ', "'.$row[80].'"';
	$query.= ', "'.$row[52].'"';
	$query.= ', "'.$row[53].'"';
	$query.= ')';
	$mysqli->query($query);
	
	$id_info = $mysqli->insert_id;
	
	// Actividades
	if($row[87] == "T"){
		$query = 'INSERT INTO cgn_erp_clientes_actividades(`id_info`, `id_actividad`) VALUES("'.$id_info.'", "1")';
		$mysqli->query($query);
		}
	if($row[85] == "T"){
		$query = 'INSERT INTO cgn_erp_clientes_actividades(`id_info`, `id_actividad`) VALUES("'.$id_info.'", "2")';
		$mysqli->query($query);
		}
	if($row[86] == "T"){
		$query = 'INSERT INTO cgn_erp_clientes_actividades(`id_info`, `id_actividad`) VALUES("'.$id_info.'", "3")';
		$mysqli->query($query);
		}
	if($row[84] == "T"){
		$query = 'INSERT INTO cgn_erp_clientes_actividades(`id_info`, `id_actividad`) VALUES("'.$id_info.'", "4")';
		$mysqli->query($query);
		}
	if($row[82] == "T"){
		$query = 'INSERT INTO cgn_erp_clientes_actividades(`id_info`, `id_actividad`) VALUES("'.$id_info.'", "5")';
		$mysqli->query($query);
		}
	if($row[83] == "T"){
		$query = 'INSERT INTO cgn_erp_clientes_actividades(`id_info`, `id_actividad`) VALUES("'.$id_info.'", "6")';
		$mysqli->query($query);
		}
	if($row[81] == "T"){
		$query = 'INSERT INTO cgn_erp_clientes_actividades(`id_info`, `id_actividad`) VALUES("'.$id_info.'", "7")';
		$mysqli->query($query);
		}
	
	// Datos de contacto
	if($row[8] != ''){
		$query = 'INSERT INTO cgn_erp_clientes_contacto(`id_info`, `tipo`, `valor`, `seccion`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "e"';
		$query.= ', "'.$row[8].'"';
		$query.= ', "e"';
		$query.= ')';
		$mysqli->query($query);
		}
	
	if($row[12] != ''){
		$query = 'INSERT INTO cgn_erp_clientes_contacto(`id_info`, `tipo`, `valor`, `seccion`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "t"';
		$query.= ', "'.$row[12].'"';
		$query.= ', "e"';
		$query.= ')';
		$mysqli->query($query);
		}
	
	if($row[13] != ''){
		$query = 'INSERT INTO cgn_erp_clientes_contacto(`id_info`, `tipo`, `valor`, `seccion`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "t"';
		$query.= ', "'.$row[13].'"';
		$query.= ', "e"';
		$query.= ')';
		$mysqli->query($query);
		}
	
	if($row[18] != ''){
		$query = 'INSERT INTO cgn_erp_clientes_contacto(`id_info`, `tipo`, `valor`, `seccion`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "e"';
		$query.= ', "'.$row[18].'"';
		$query.= ', "e"';
		$query.= ')';
		$mysqli->query($query);
		}
	
	// Sucursales
	if($row[70] == 1){
		$query = 'INSERT INTO cgn_erp_clientes_sucursales(`id_info`, `id_departamento`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "1"';
		$query.= ')';
		$mysqli->query($query);
		}
	if($row[72] == 1){
		$query = 'INSERT INTO cgn_erp_clientes_sucursales(`id_info`, `id_departamento`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "2"';
		$query.= ')';
		$mysqli->query($query);
		}
	if($row[71] == 1){
		$query = 'INSERT INTO cgn_erp_clientes_sucursales(`id_info`, `id_departamento`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "3"';
		$query.= ')';
		$mysqli->query($query);
		}
	if($row[74] == 1){
		$query = 'INSERT INTO cgn_erp_clientes_sucursales(`id_info`, `id_departamento`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "4"';
		$query.= ')';
		$mysqli->query($query);
		}
	if($row[73] == 1){
		$query = 'INSERT INTO cgn_erp_clientes_sucursales(`id_info`, `id_departamento`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "5"';
		$query.= ')';
		$mysqli->query($query);
		}
	if($row[76] == 1){
		$query = 'INSERT INTO cgn_erp_clientes_sucursales(`id_info`, `id_departamento`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "6"';
		$query.= ')';
		$mysqli->query($query);
		}
	if($row[77] == 1){
		$query = 'INSERT INTO cgn_erp_clientes_sucursales(`id_info`, `id_departamento`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "7"';
		$query.= ')';
		$mysqli->query($query);
		}
	if($row[75] == 1){
		$query = 'INSERT INTO cgn_erp_clientes_sucursales(`id_info`, `id_departamento`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "8"';
		$query.= ')';
		$mysqli->query($query);
		}
	if($row[78] == 1){
		$query = 'INSERT INTO cgn_erp_clientes_sucursales(`id_info`, `id_departamento`) VALUES(';
		$query.= '"'.$id_info.'"';
		$query.= ', "9"';
		$query.= ')';
		$mysqli->query($query);
		}
	}



echo '<h3>Terminado '.$n.'</h3>';
?>