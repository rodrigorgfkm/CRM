<?
$bd_host = 'localhost';
$bd_usuario = 'cybernet_cncimporta';
$bd_password = 'UbBv[Txqe0?%';
$bd_base = 'cybernet_cncimporta';

$mysqli = new mysqli($bd_host, $bd_usuario, $bd_password, $bd_base);

/* comprobar la conexión */
if (mysqli_connect_errno()) {
    printf("Falló la conexión: %s\n", mysqli_connect_error());
    exit();
}


/*$con = mysql_connect($bd_host, $bd_usuario, $bd_password) or die('No se puede conectar a la BD');
$bd = mysql_select_db($bd_base, $con);*/

function comilla($txt){
	$txt = str_replace('"', '', $txt);
	$txt = str_replace("'", '', $txt);
	return $txt;
	}
function fecha($fecha){
	$f = explode('/', $fecha);
	return $f[2].'-'.$f[0].'-'.$f[1];
	}

echo '<h1>Importa</h1>';
$n = 0;

$query = 'SELECT * FROM asociados WHERE 1 ORDER BY id';
$resultado = $mysqli->query($query);

while ($row = $resultado->fetch_row()){
	$n++;
	$reg = (int) $row[1];
	
	$query = 'INSERT INTO cgn_users(`name`, `username`, `email`, `password`, `registerDate`) VALUES(';
	$query.= '"'.$row[2].'"';
	$query.= ', "'.$reg.'"';
	$query.= ', "'.$row[8].'"';
	$query.= ', "'.md5($reg).'"';
	$query.= ', "'.fecha($row[22]).'"';
	$query.= ')';
	$mysqli->query($query);
	
	$id_usuario = $mysqli->insert_id;
	
	$query = 'INSERT INTO cgn_user_usergroup_map(`user_id`, `group_id`) VALUES("'.$id_usuario.'", "2")';
	$mysqli->query($query);
}



echo '<h3>Terminado '.$n.'</h3>';
?>