<?
$bd_host = 'localhost';
$bd_usuario = 'cybernet_cncimporta';
$bd_password = 'UbBv[Txqe0?%';
$bd_base = 'cybernet_cncimporta';

$mysqli = new mysqli($bd_host, $bd_usuario, $bd_password, $bd_base);

/* comprobar la conexión */
if (mysqli_connect_errno()) {
    printf("Falló la conexión: %s\n", mysqli_connect_error());
    exit();
}


/*$con = mysql_connect($bd_host, $bd_usuario, $bd_password) or die('No se puede conectar a la BD');
$bd = mysql_select_db($bd_base, $con);*/

function comilla($txt){
	$txt = str_replace('"', '', $txt);
	$txt = str_replace("'", '', $txt);
	return $txt;
	}
function fecha($fecha){
	$f = explode('/', $fecha);
	return $f[2].'-'.$f[0].'-'.$f[1];
	}

echo '<h1>Importa</h1>';
$n = 0;

$query = 'SELECT * FROM masiva WHERE 1 ORDER BY id';
$resultado = $mysqli->query($query);

while ($row = $resultado->fetch_row()){
	$n++;
	$reg = (int) $row[1];
	
	$query = 'UPDATE cgn_erp_clientes SET masiva = "1" WHERE registro = "'.$reg.'"';
	$mysqli->query($query);
}



echo '<h3>Terminado '.$n.'</h3>';
?>