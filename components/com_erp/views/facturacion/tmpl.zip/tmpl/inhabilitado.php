<?php defined('_JEXEC') or die;?> 
<div class="row">
  <section class="col-lg-12 connectedSortable">
    <div class="box box-success">
      <div class="box-header">
        <i class="fa fa-comments-o"></i>
		<!-- Título de la vista -->
        <h3 class="box-title">Facturación</h3>
      </div>
      <div class="box-body">
        <div class="row-fluid">
          <p align="center" style="font-size:16px;">Este sistema no está habilitado en su  Plataforma.<br>
            Para adquirirlo por favor comuníquese  con su Ejecutivo de Ventas o envíe un correo-e a <a href="mailto:comercial@cyberglobalnet.com">comercial@cyberglobalnet.com</a> <br>
            Para mayores detalles de nuestros  productos visite nuestro sitio Web en <a href="http://www.CyberGlobalNet.com">www.CyberGlobalNet.com</a>.</p>
        </div>
        <div class="row-fluid">
          <p align="center"><strong>Declaración  de principios de nuestro programa de Responsabilidad Social Empresarial – RSE.</strong></p>
Nuestro compromiso con el medio ambiente genera  una responsabilidad de un menor uso del papel en las empresas. CyberGlobalNet  está trabajando por brindarle sistemas que eviten la impresión de documentos en  papel, convirtiendo y optimizando la experiencia virtual. </div>
      </div>
    </div>
  </section>
</div>